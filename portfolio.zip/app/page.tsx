import Image from "next/image"
import { Github, Mail, MapPin, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ThemeToggle } from "@/components/theme-toggle"

export default function Portfolio() {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      {/* Header/Navigation */}
      <header className="sticky top-0 z-10 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800">
        <div className="container flex items-center justify-between h-16 px-4 mx-auto">
          <h1 className="text-2xl font-bold text-red-600 dark:text-red-500">Shrikar</h1>
          <nav className="hidden md:flex items-center space-x-8">
            <ul className="flex space-x-8">
              {["Home", "About", "Skills", "Projects", "Contact"].map((item) => (
                <li key={item}>
                  <a
                    href={`#${item.toLowerCase()}`}
                    className="text-gray-700 dark:text-gray-300 transition-colors hover:text-red-600 dark:hover:text-red-500"
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
            <ThemeToggle />
          </nav>
          <div className="flex items-center md:hidden">
            <ThemeToggle />
            <Button variant="outline" className="ml-2">
              Menu
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section
        id="home"
        className="relative py-20 bg-gradient-to-r from-red-50 to-white dark:from-gray-900 dark:to-gray-800"
      >
        <div className="container px-4 mx-auto">
          <div className="flex flex-col items-center md:flex-row md:justify-between">
            <div className="mb-10 text-center md:text-left md:mb-0 md:w-1/2">
              <h1 className="mb-4 text-4xl font-bold text-gray-900 dark:text-white md:text-5xl lg:text-6xl">
                Hi, I'm <span className="text-red-600 dark:text-red-500">Shrikar</span>
              </h1>
              <p className="mb-6 text-xl text-gray-600 dark:text-gray-300">Web Developer & Designer</p>
              <div className="flex flex-wrap justify-center gap-4 md:justify-start">
                <Button className="bg-red-600 hover:bg-red-700 dark:bg-red-700 dark:hover:bg-red-600">
                  View Projects
                </Button>
                <Button
                  variant="outline"
                  className="border-red-600 text-red-600 hover:bg-red-50 dark:border-red-500 dark:text-red-500 dark:hover:bg-gray-800"
                >
                  Contact Me
                </Button>
              </div>
            </div>
            <div className="relative w-64 h-64 overflow-hidden rounded-full border-4 border-red-600 dark:border-red-500 md:w-80 md:h-80">
              <Image src="/profile-pic.jpg" alt="Shrikar" fill className="object-cover" priority />
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white dark:bg-gray-900">
        <div className="container px-4 mx-auto">
          <h2 className="mb-12 text-3xl font-bold text-center text-gray-900 dark:text-white md:text-4xl">
            About <span className="text-red-600 dark:text-red-500">Me</span>
          </h2>
          <div className="grid gap-8 md:grid-cols-2">
            <div>
              <p className="mb-4 text-lg text-gray-700 dark:text-gray-300">
                I am a passionate web developer based in Bengaluru, focused on creating beautiful and functional
                websites. With expertise in HTML, CSS, and JavaScript, I build responsive and user-friendly web
                applications.
              </p>
              <p className="mb-6 text-lg text-gray-700 dark:text-gray-300">
                My goal is to deliver high-quality solutions that meet client needs while providing an exceptional user
                experience. I'm constantly learning new technologies to stay at the forefront of web development.
              </p>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <MapPin className="text-red-600 dark:text-red-500" size={20} />
                  <span className="text-gray-700 dark:text-gray-300">Bengaluru, India</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="text-red-600 dark:text-red-500" size={20} />
                  <span className="text-gray-700 dark:text-gray-300">rshrikar62@gmail.com</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="text-red-600 dark:text-red-500" size={20} />
                  <span className="text-gray-700 dark:text-gray-300">+91 7022146310</span>
                </div>
              </div>
            </div>
            <div className="flex items-center justify-center">
              <div className="relative w-full max-w-md h-80 overflow-hidden rounded-lg shadow-lg">
                <Image src="/placeholder.svg?height=320&width=480" alt="About Shrikar" fill className="object-cover" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 bg-red-50 dark:bg-gray-800">
        <div className="container px-4 mx-auto">
          <h2 className="mb-12 text-3xl font-bold text-center text-gray-900 dark:text-white md:text-4xl">
            My <span className="text-red-600 dark:text-red-500">Skills</span>
          </h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[
              { name: "HTML5", level: 90 },
              { name: "CSS3", level: 85 },
              { name: "JavaScript", level: 80 },
              { name: "React", level: 75 },
              { name: "Node.js", level: 70 },
              { name: "UI/UX Design", level: 80 },
            ].map((skill) => (
              <div key={skill.name} className="p-6 bg-white dark:bg-gray-900 rounded-lg shadow-md">
                <h3 className="mb-4 text-xl font-semibold text-gray-800 dark:text-white">{skill.name}</h3>
                <div className="w-full h-3 mb-2 bg-gray-200 dark:bg-gray-700 rounded-full">
                  <div
                    className="h-3 bg-red-600 dark:bg-red-500 rounded-full"
                    style={{ width: `${skill.level}%` }}
                  ></div>
                </div>
                <span className="text-sm text-gray-600 dark:text-gray-400">{skill.level}%</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 bg-white dark:bg-gray-900">
        <div className="container px-4 mx-auto">
          <h2 className="mb-12 text-3xl font-bold text-center text-gray-900 dark:text-white md:text-4xl">
            My <span className="text-red-600 dark:text-red-500">Projects</span>
          </h2>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3].map((project) => (
              <Card
                key={project}
                className="overflow-hidden transition-transform hover:scale-105 dark:bg-gray-800 dark:border-gray-700"
              >
                <div className="relative w-full h-48">
                  <Image
                    src={`/placeholder.svg?height=192&width=384&text=Project+${project}`}
                    alt={`Project ${project}`}
                    fill
                    className="object-cover"
                  />
                </div>
                <CardContent className="p-6">
                  <h3 className="mb-2 text-xl font-semibold text-gray-800 dark:text-white">Project Title {project}</h3>
                  <p className="mb-4 text-gray-600 dark:text-gray-300">
                    A brief description of this project and the technologies used to build it.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {["HTML", "CSS", "JavaScript"].map((tech) => (
                      <span
                        key={tech}
                        className="px-3 py-1 text-xs text-red-600 dark:text-red-500 bg-red-100 dark:bg-red-900/30 rounded-full"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                  <div className="flex justify-between mt-4">
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-red-600 dark:text-red-500 border-red-600 dark:border-red-500 hover:bg-red-50 dark:hover:bg-red-900/20"
                    >
                      Demo
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-red-600 dark:text-red-500 border-red-600 dark:border-red-500 hover:bg-red-50 dark:hover:bg-red-900/20"
                    >
                      Code
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-red-50 dark:bg-gray-800">
        <div className="container px-4 mx-auto">
          <h2 className="mb-12 text-3xl font-bold text-center text-gray-900 dark:text-white md:text-4xl">
            Contact <span className="text-red-600 dark:text-red-500">Me</span>
          </h2>
          <div className="grid gap-8 md:grid-cols-2">
            <div>
              <h3 className="mb-4 text-2xl font-semibold text-gray-800 dark:text-white">Get In Touch</h3>
              <p className="mb-6 text-gray-600 dark:text-gray-300">
                Feel free to reach out to me for any inquiries or collaboration opportunities. I'm always open to
                discussing new projects and ideas.
              </p>
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="flex items-center justify-center w-12 h-12 text-white bg-red-600 dark:bg-red-700 rounded-full">
                    <Phone size={20} />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Phone</h4>
                    <p className="text-gray-800 dark:text-white">+91 7022146310</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex items-center justify-center w-12 h-12 text-white bg-red-600 dark:bg-red-700 rounded-full">
                    <Mail size={20} />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Email</h4>
                    <p className="text-gray-800 dark:text-white">rshrikar62@gmail.com</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex items-center justify-center w-12 h-12 text-white bg-red-600 dark:bg-red-700 rounded-full">
                    <MapPin size={20} />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Location</h4>
                    <p className="text-gray-800 dark:text-white">Bengaluru, India</p>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <form className="p-6 bg-white dark:bg-gray-900 rounded-lg shadow-md">
                <div className="grid gap-4 mb-4 md:grid-cols-2">
                  <div>
                    <label htmlFor="name" className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                      Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      className="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-red-600 dark:focus:ring-red-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                      placeholder="Your name"
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      className="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-red-600 dark:focus:ring-red-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                      placeholder="Your email"
                    />
                  </div>
                </div>
                <div className="mb-4">
                  <label htmlFor="subject" className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                    Subject
                  </label>
                  <input
                    type="text"
                    id="subject"
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-red-600 dark:focus:ring-red-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                    placeholder="Subject"
                  />
                </div>
                <div className="mb-4">
                  <label htmlFor="message" className="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                    Message
                  </label>
                  <textarea
                    id="message"
                    rows={4}
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-red-600 dark:focus:ring-red-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                    placeholder="Your message"
                  ></textarea>
                </div>
                <Button className="w-full bg-red-600 hover:bg-red-700 dark:bg-red-700 dark:hover:bg-red-600">
                  Send Message
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 text-white bg-gray-900 dark:bg-gray-950">
        <div className="container px-4 mx-auto">
          <div className="flex flex-col items-center justify-between md:flex-row">
            <div className="mb-4 md:mb-0">
              <h2 className="text-2xl font-bold text-red-500">Shrikar</h2>
              <p className="text-gray-400">Web Developer & Designer</p>
            </div>
            <div className="flex space-x-4">
              <a
                href="#"
                className="p-2 text-white transition-colors rounded-full hover:bg-red-600 dark:hover:bg-red-700"
              >
                <Github size={20} />
              </a>
              <a
                href="#"
                className="p-2 text-white transition-colors rounded-full hover:bg-red-600 dark:hover:bg-red-700"
              >
                <Mail size={20} />
              </a>
              <a
                href="#"
                className="p-2 text-white transition-colors rounded-full hover:bg-red-600 dark:hover:bg-red-700"
              >
                <Phone size={20} />
              </a>
            </div>
          </div>
          <div className="pt-6 mt-6 text-center border-t border-gray-800 dark:border-gray-700">
            <p className="text-gray-400">© {new Date().getFullYear()} Shrikar. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

